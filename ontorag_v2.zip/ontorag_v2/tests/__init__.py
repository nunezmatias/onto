"""
OntoRAG Tests

Run tests with:
    $ pytest tests/ -v
"""
